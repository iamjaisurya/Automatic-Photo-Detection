Automatic Sign and Photo Detection for Online Application Services

Steps to follow:

	1. Download the zip file and extract it under /var/www/html/ folder
	2. Open your terminal as a root user and type the following commands:
		i. cd /var/www/html/
		ii. php -S localhost:8080
	3. Open your browser and type http://localhost:8080